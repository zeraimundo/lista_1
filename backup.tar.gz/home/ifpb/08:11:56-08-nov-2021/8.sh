#!/bin/bash 

echo "O valor da soma dos argumentos inseridos é = $(($1+$2))"
