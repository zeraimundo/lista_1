#!/bin/bash 

read -p "Digite um numero inteiro : " y
y=$(($y+42))
echo "$y"
