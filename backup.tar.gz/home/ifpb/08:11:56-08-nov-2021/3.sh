#!/bin/bash



ls ${1} >> out2.txt

ls ${2} >> out2.txt

ls ${3}>> out2.txt

ls ${4} >> out2.txt
