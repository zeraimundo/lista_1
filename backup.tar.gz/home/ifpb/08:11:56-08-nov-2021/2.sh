#!/bin/bash


read -p "Escreva o nome do primeiro diretório:" a
ls $a >> out.txt

read -p "Escreva o nome do primeiro diretório:" b
ls $b >> out.txt

read -p "Escreva o nome do primeiro diretório:" c
ls $c >> out.txt

read -p "Escreva o nome do primeiro diretório:" d
ls $d >> out.txt
