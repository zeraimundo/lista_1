#!/bin/bash

echo -e "\nNada está tão ruim que não possa piorar\n"
