#!/bin/bash

echo -e "\nSUBSTITUIÇÃO DE VARIÁVEL\nO Linux Bash Shell procura todos os sinais ‘$’ antes de executar o comando e substitui-os pelo valor da variável. O processo de substituição da variável Bash é executado apenas uma vez.
echo"Exemplos:"
echo
Nome="Gabibol"
echo 'O nome do usuário é $Nome'
echo "O nome do usuário é $Nome"
echo

echo -e "\nSUBSTITUIÇÃO DE SHElL"
echo -e "Também conhecido como substituição de comandos."
echo -e "Permite que o shell substitua o comando fornecido entre" '$()' "por seu resultado."
echo -e "Exemplos:\n"
echo -e '       Data = $(date)'
echo -e "       Data = $(date)\n"
echo -e '       Seu diretório atual é: $(pwd)'
echo -e "       Seu diretório atual é: $(pwd)"
echo -e "\nSUBSTITUIÇÃO ARITMÉTICA"

echo -e "Exemplos:\n"
echo -e '       Soma = $((10+5))'
echo -e "       Soma = $((10+5))"
Soma=$(( 10 + 5 ))
echo -e '       Multip = $(( $Soma * 2 ))'
echo -e '       Multip = $((' "$Soma" '* 2 )) <-- note também a substituição de variável'
echo -e "       Multip = $(( $Soma * 2 ))"
