#!/bin/bash 

echo "$(( ( $1 + 1 ) * ( $2 + 2) ))"
